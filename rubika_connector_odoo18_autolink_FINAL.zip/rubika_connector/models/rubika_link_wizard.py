from odoo import fields, models, _
from odoo.exceptions import UserError


class RubikaLinkWizard(models.TransientModel):
    _name = "rubika.link.wizard"
    _description = "Link Rubika Conversation to Customer"

    conversation_id = fields.Many2one("rubika.conversation", required=True, readonly=True)
    partner_id = fields.Many2one("res.partner", string="Odoo Customer", required=True)
    chat_id = fields.Char(related="conversation_id.chat_id", readonly=True)
    account_id = fields.Many2one(related="conversation_id.account_id", readonly=True)

    def action_link(self):
        self.ensure_one()
        conversation = self.conversation_id.sudo()
        partner = self.partner_id.sudo()
        if conversation.account_id != self.account_id:
            raise UserError(_("Invalid Rubika account."))
        partner.write({
            "rubika_chat_id": conversation.chat_id,
            "rubika_account_id": conversation.account_id.id,
        })
        # Keep the existing Rubika user ID when it is already known from a message.
        sender = self.env["rubika.message"].sudo().search([
            ("conversation_id", "=", conversation.id),
            ("sender_id", "!=", False),
        ], order="create_date desc", limit=1)
        if sender and sender.sender_id and not partner.rubika_user_id:
            partner.rubika_user_id = sender.sender_id
        conversation.write({
            "partner_id": partner.id,
            "name": partner.name,
        })
        self.env["rubika.message"].sudo().search([
            ("conversation_id", "=", conversation.id),
        ]).write({"partner_id": partner.id})
        return {"type": "ir.actions.act_window_close"}
