import json
import logging
import urllib.error
import urllib.request

from odoo import api, fields, models, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class RubikaAccount(models.Model):
    _name = "rubika.account"
    _description = "Rubika Bot Account"
    _order = "id desc"

    name = fields.Char(required=True, default="Rubika Bot")
    active = fields.Boolean(default=True)
    bot_token = fields.Char(string="Bot Token", required=True, copy=False)
    api_base_url = fields.Char(
        string="API Base URL",
        required=True,
        default="https://botapi.rubika.ir/v3",
        help="Rubika Bot API base URL. Do not add the bot token here.",
    )
    polling_enabled = fields.Boolean(default=True)
    last_offset_id = fields.Char(copy=False)
    last_poll_at = fields.Datetime(copy=False)
    last_error = fields.Text(copy=False)
    bot_id = fields.Char(readonly=True, copy=False)
    bot_username = fields.Char(readonly=True, copy=False)
    bot_name = fields.Char(readonly=True, copy=False)
    conversation_ids = fields.One2many("rubika.conversation", "account_id")
    company_id = fields.Many2one("res.company", default=lambda self: self.env.company, required=True)
    deep_link_base = fields.Char(
        string="قالب لینک اختصاصی",
        default="https://rubika.ir/{username}?start={token}",
        help="قالب لینکی که برای اتصال خودکار مخاطب استفاده می‌شود. {username} و {token} "
             "جایگزین می‌شوند. این فرمت باید یک‌بار با بات واقعی تست شود؛ اگر روبیکا رفتار "
             "متفاوتی داشت، همین‌جا اصلاح کنید.",
    )
    auto_link_by_phone = fields.Boolean(
        string="تطبیق خودکار با شماره موبایل",
        default=True,
        help="اگر مکالمه‌ای هنوز به مشتری متصل نشده و اولین پیام آن یک شماره موبایل معتبر "
             "باشد، سیستم تلاش می‌کند آن را با شماره موبایل/تلفن مخاطبین Odoo تطبیق دهد.",
    )

    def _build_deep_link(self, token):
        self.ensure_one()
        template = self.deep_link_base or "https://rubika.ir/{username}?start={token}"
        return template.format(username=self.bot_username or "", token=token or "")

    def _api_url(self, method):
        self.ensure_one()
        base = (self.api_base_url or "").rstrip("/")
        token = (self.bot_token or "").strip()
        if not base or not token:
            raise UserError(_("Rubika API URL and Bot Token are required."))
        return "%s/%s/%s" % (base, token, method)

    def _api_call(self, method, payload=None, timeout=20):
        self.ensure_one()
        data = json.dumps(payload or {}).encode("utf-8")
        req = urllib.request.Request(
            self._api_url(method),
            data=data,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as response:
                raw = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise UserError(_("Rubika HTTP error %s: %s") % (exc.code, body[:1000]))
        except urllib.error.URLError as exc:
            raise UserError(_("Could not reach Rubika API: %s") % exc.reason)
        except Exception as exc:
            raise UserError(_("Rubika API connection error: %s") % exc)

        try:
            result = json.loads(raw)
        except json.JSONDecodeError:
            raise UserError(_("Rubika returned invalid JSON: %s") % raw[:1000])

        if isinstance(result, dict) and isinstance(result.get("data"), dict):
            data_part = dict(result["data"])
            if "status" not in data_part and "status" in result:
                data_part["status"] = result["status"]
            return data_part
        return result

    def action_test_connection(self):
        self.ensure_one()
        result = self._api_call("getMe")
        if not isinstance(result, dict):
            raise UserError(_("Unexpected response from Rubika getMe."))
        self.bot_id = str(result.get("bot_id") or result.get("id") or "")
        self.bot_username = result.get("username") or result.get("user_username") or ""
        self.bot_name = result.get("first_name") or result.get("name") or self.name
        self.last_error = False
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Rubika"),
                "message": _("Connection successful. Bot: %s") % (self.bot_username or self.bot_name or self.bot_id),
                "type": "success",
                "sticky": False,
            },
        }

    def action_refresh_rubika_actions(self):
        """Create/update the generic Odoo Action-menu bindings.

        This is intentionally dynamic: every installed model that uses the
        standard Chatter and has a res.partner partner_id gets the same
        «ارسال با روبیکا» action without requiring a separate inherited form
        view.
        """
        from ..hooks import _sync_server_actions
        _sync_server_actions(self.env)
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("روبیکا"),
                "message": _("گزینه «ارسال با روبیکا» برای فرم‌های سازگار فعال شد. صفحه را تازه‌سازی کنید."),
                "type": "success",
                "sticky": False,
            },
        }

    def action_poll_now(self):
        self.ensure_one()
        self._poll_updates()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Rubika"),
                "message": _("Polling completed."),
                "type": "success",
                "sticky": False,
            },
        }

    def _poll_updates(self):
        for account in self.filtered(lambda r: r.active and r.polling_enabled):
            try:
                payload = {"limit": 10}
                if account.last_offset_id:
                    payload["offset_id"] = account.last_offset_id
                result = account._api_call("getUpdates", payload, timeout=20)
                updates = result.get("updates", []) if isinstance(result, dict) else []
                if not isinstance(updates, list):
                    raise UserError(_("Rubika returned an invalid updates list."))
                for update in updates:
                    account._process_update(update)
                next_offset = result.get("next_offset_id") if isinstance(result, dict) else None
                if next_offset:
                    account.last_offset_id = str(next_offset)
                account.last_poll_at = fields.Datetime.now()
                account.last_error = False
            except Exception as exc:
                _logger.exception("Rubika polling failed for account %s", account.id)
                account.last_poll_at = fields.Datetime.now()
                account.last_error = str(exc)

    def _find_partner_for_rubika(self, chat_id, sender_id):
        """Match an incoming Rubika identity to an already-linked Odoo contact.

        Priority: same bot + chat ID, then user ID. This never creates a link by
        itself; it only recognizes a contact that was linked before (manually,
        by deep link, or by phone match). See _link_partner_from_update for the
        logic that establishes a *new* link on first contact.
        """
        Partner = self.env["res.partner"].sudo()
        chat_id = str(chat_id or "")
        sender_id = str(sender_id or "")
        partner = False
        if chat_id:
            partner = Partner.search([
                ("rubika_account_id", "=", self.id),
                ("rubika_chat_id", "=", chat_id),
            ], limit=1)
        if not partner and sender_id:
            partner = Partner.search([
                ("rubika_account_id", "=", self.id),
                ("rubika_user_id", "=", sender_id),
            ], limit=1)
        if partner:
            vals = {}
            if chat_id and partner.rubika_chat_id != chat_id:
                vals["rubika_chat_id"] = chat_id
            if sender_id and partner.rubika_user_id != sender_id:
                vals["rubika_user_id"] = sender_id
            if vals:
                partner.write(vals)
        return partner

    @staticmethod
    def _extract_start_token(update, message):
        """Best-effort extraction of a deep-link start payload from an update.

        Rubika's public docs confirm an ``aux_data.start_id`` field is delivered
        on button/inline interactions; the exact placement for the very first
        "start" event is not fully documented, so several plausible locations
        are checked. A "/start <token>" text fallback is also supported, which
        is a common convention when a bot framework does not surface the
        official payload. Verify against your real bot and adjust if needed.
        """
        candidates = []
        for holder in (update, message, (message or {}).get("aux_data"), update.get("aux_data")):
            if isinstance(holder, dict):
                aux = holder.get("aux_data") if "aux_data" in holder else holder
                if isinstance(aux, dict) and aux.get("start_id"):
                    candidates.append(str(aux["start_id"]))
        text = (message or {}).get("text") or ""
        if text.startswith("/start"):
            parts = text.split(None, 1)
            if len(parts) == 2 and parts[1].strip():
                candidates.append(parts[1].strip())
        return candidates[0] if candidates else False

    @staticmethod
    def _normalize_ir_phone(value):
        """Normalize an Iranian mobile/phone number to its last 10 digits
        (e.g. '+98 912 345 6789', '0912-345-6789' -> '9123456789') so different
        writing styles can be compared. Returns False if not phone-like."""
        digits = "".join(ch for ch in (value or "") if ch.isdigit())
        if len(digits) < 9:
            return False
        return digits[-10:]

    def _find_partner_by_phone(self, text):
        """Try to match a plain-text message that looks like a phone number
        against existing Odoo contacts (phone/mobile), when auto_link_by_phone
        is enabled. Only auto-links on a single unambiguous match."""
        self.ensure_one()
        if not self.auto_link_by_phone:
            return False
        normalized = self._normalize_ir_phone(text)
        if not normalized:
            return False
        Partner = self.env["res.partner"].sudo()
        candidates = Partner.search([
            ("rubika_chat_id", "=", False),
            "|", ("phone", "!=", False), ("mobile", "!=", False),
        ])
        matches = candidates.filtered(
            lambda p: self._normalize_ir_phone(p.phone) == normalized
            or self._normalize_ir_phone(p.mobile) == normalized
        )
        return matches[:1] if len(matches) == 1 else False

    def _link_partner_from_update(self, update, message, chat_id, sender_id):
        """Establish a *new* chat_id <-> partner link on first contact, trying,
        in order: deep-link start token, then (if enabled) a phone number typed
        as the first message. Returns the linked partner, or an empty recordset
        if no automatic match was found (falls back to manual linking)."""
        self.ensure_one()
        Partner = self.env["res.partner"].sudo()

        token = self._extract_start_token(update, message)
        if token:
            partner = Partner.search([("rubika_link_token", "=", token)], limit=1)
            if partner:
                partner.write({
                    "rubika_chat_id": chat_id,
                    "rubika_user_id": sender_id or partner.rubika_user_id,
                    "rubika_account_id": self.id,
                    "rubika_link_token": False,  # one-time use, avoid replay/leak reuse
                })
                return partner

        text = (message or {}).get("text") or ""
        partner = self._find_partner_by_phone(text)
        if partner:
            partner.write({
                "rubika_chat_id": chat_id,
                "rubika_user_id": sender_id or partner.rubika_user_id,
                "rubika_account_id": self.id,
            })
            return partner

        return Partner

    def _process_update(self, update):
        self.ensure_one()
        if not isinstance(update, dict):
            return
        message = update.get("new_message") or {}
        if not isinstance(message, dict):
            message = {}
        chat_id = update.get("chat_id") or message.get("chat_id")
        if not chat_id:
            return
        if message.get("sender_type") == "Bot":
            return

        sender_id = message.get("sender_id") or ""
        text = message.get("text") or ""
        message_id = message.get("message_id") or update.get("message_id") or ""
        chat_id = str(chat_id)
        sender_id = str(sender_id) if sender_id else ""

        Conversation = self.env["rubika.conversation"].sudo()
        conversation = Conversation.search([
            ("account_id", "=", self.id),
            ("chat_id", "=", chat_id),
        ], limit=1)

        partner = self._find_partner_for_rubika(chat_id, sender_id)
        auto_linked = False
        if not partner:
            partner = self._link_partner_from_update(update, message, chat_id, sender_id)
            auto_linked = bool(partner)
        sender_name = (
            message.get("sender_name")
            or message.get("first_name")
            or message.get("sender_username")
            or sender_id
            or chat_id
        )

        if not conversation:
            conversation = Conversation.create({
                "name": partner.name if partner else sender_name,
                "account_id": self.id,
                "chat_id": chat_id,
                "partner_id": partner.id if partner else False,
            })
        elif partner and conversation.partner_id != partner:
            conversation.sudo().write({"partner_id": partner.id, "name": partner.name})

        if message_id:
            exists = self.env["rubika.message"].sudo().search([
                ("account_id", "=", self.id),
                ("external_message_id", "=", str(message_id)),
            ], limit=1)
            if exists:
                return

        self.env["rubika.message"].sudo().create({
            "conversation_id": conversation.id,
            "account_id": self.id,
            "partner_id": partner.id if partner else False,
            "direction": "in",
            "message_type": "text" if text else "event",
            "external_message_id": str(message_id) if message_id else False,
            "sender_id": sender_id or False,
            "chat_id": chat_id,
            "body": text or (update.get("type") or "Rubika update"),
            "raw_payload": json.dumps(update, ensure_ascii=False),
        })
        conversation.sudo().write({
            "last_message": text or (update.get("type") or "Rubika update"),
            "last_message_at": fields.Datetime.now(),
            "unread_count": conversation.unread_count + 1,
        })

        if auto_linked and partner:
            try:
                self._api_call("sendMessage", {
                    "chat_id": chat_id,
                    "text": _("سلام %s، حساب شما با موفقیت به سیستم متصل شد. ✅") % (partner.name or ""),
                })
            except Exception:
                _logger.exception("Rubika: failed to send auto-link confirmation to chat %s", chat_id)


    def _request_send_file(self, filename, size, mimetype):
        self.ensure_one()
        result = self._api_call("requestSendFile", {
            "file_name": filename,
            "size": size,
            "mime": mimetype or "application/octet-stream",
        }, timeout=30)
        if not isinstance(result, dict):
            raise UserError(_("پاسخ نامعتبر از requestSendFile روبیکا دریافت شد."))
        upload_url = result.get("upload_url")
        file_id = result.get("id") or result.get("file_id")
        access_hash_send = result.get("access_hash_send")
        if not upload_url or not file_id or not access_hash_send:
            raise UserError(_("اطلاعات آپلود فایل از روبیکا ناقص است: %s") % result)
        return result

    def _upload_bytes(self, upload_info, file_bytes):
        self.ensure_one()
        import urllib.request
        import urllib.error
        total = len(file_bytes)
        chunk_size = 131072
        total_parts = max(1, (total + chunk_size - 1) // chunk_size)
        last_data = None
        for part in range(1, total_parts + 1):
            start = (part - 1) * chunk_size
            chunk = file_bytes[start:start + chunk_size]
            headers = {
                "auth": (self.bot_token or "").strip(),
                "chunk-size": str(len(chunk)),
                "file-id": str(upload_info["id"]),
                "access-hash-send": str(upload_info["access_hash_send"]),
                "part-number": str(part),
                "total-part": str(total_parts),
                "content-type": "application/octet-stream",
                "content-length": str(len(chunk)),
            }
            req = urllib.request.Request(
                upload_info["upload_url"],
                data=chunk,
                headers=headers,
                method="POST",
            )
            try:
                with urllib.request.urlopen(req, timeout=60) as response:
                    raw = response.read().decode("utf-8", errors="replace")
                    last_data = json.loads(raw)
            except Exception as exc:
                raise UserError(_("آپلود فایل در روبیکا ناموفق بود: %s") % exc)
        return last_data

    def _upload_and_send_file(self, chat_id, filename, file_bytes, mimetype, caption=""):
        self.ensure_one()
        upload_info = self._request_send_file(filename, len(file_bytes), mimetype)
        self._upload_bytes(upload_info, file_bytes)
        file_type = "File"
        if (mimetype or "").startswith("image/"):
            file_type = "Image"
        elif (mimetype or "").startswith("video/"):
            file_type = "Video"
        elif (mimetype or "").startswith("audio/"):
            file_type = "Voice"
        payload = {
            "chat_id": str(chat_id),
            "file_id": str(upload_info["id"]),
            "text": caption or "",
        }
        result = self._api_call("sendFile", payload, timeout=30)
        return result


    def action_refresh_rubika_actions(self):
        """Create/update the contextual 'Send to Rubika' action on Odoo business models."""
        self.ensure_one()
        ServerAction = self.env["ir.actions.server"].sudo()
        Model = self.env["ir.model"].sudo()
        code = "action = env['rubika.send.wizard'].action_from_context()"
        created = 0
        for ir_model in Model.search([]):
            model_name = ir_model.model
            if model_name.startswith(("ir.", "bus.", "mail.", "web.")):
                continue
            try:
                model_cls = self.env[model_name]
            except Exception:
                continue
            # Contextual actions are useful on models that support chatter/attachments.
            if not hasattr(model_cls, "message_post"):
                continue
            existing = ServerAction.search([
                ("binding_model_id", "=", ir_model.id),
                ("name", "=", "ارسال به روبیکا"),
            ], limit=1)
            vals = {
                "name": "ارسال به روبیکا",
                "model_id": ir_model.id,
                "binding_model_id": ir_model.id,
                "binding_view_types": "list,form",
                "state": "code",
                "code": code,
            }
            if existing:
                existing.write(vals)
            else:
                ServerAction.create(vals)
                created += 1
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("روبیکا"),
                "message": _("دستور «ارسال به روبیکا» برای %s بخش فعال شد.") % created,
                "type": "success",
                "sticky": False,
            },
        }

    @api.model
    def cron_poll_rubika(self):
        accounts = self.sudo().search([("active", "=", True), ("polling_enabled", "=", True)])
        accounts._poll_updates()
