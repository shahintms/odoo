/** @odoo-module **/
import { Component, onWillStart, onMounted, useState, useRef } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

class RubikaMessenger extends Component {
    setup() {
        this.orm = useService("orm");
        this.notification = useService("notification");
        this.action = useService("action");
        this.fileInput = useRef("fileInput");
        this.state = useState({
            conversations: [],
            messages: [],
            selectedId: null,
            selected: null,
            search: "",
            draft: "",
            loading: true,
            sending: false,
            showInfo: false,
            showAttachmentMenu: false,
        });
        onWillStart(async () => {
            await this.loadConversations();
        });
        onMounted(() => {
            this.scrollToBottom();
            this.timer = setInterval(() => this.loadConversations(true), 7000);
        });
    }

    willUnmount() {
        if (this.timer) clearInterval(this.timer);
    }

    get filteredConversations() {
        const q = (this.state.search || "").trim().toLowerCase();
        if (!q) return this.state.conversations;
        return this.state.conversations.filter(c =>
            (c.name || "").toLowerCase().includes(q) ||
            (c.partner_name || "").toLowerCase().includes(q) ||
            (c.chat_id || "").toLowerCase().includes(q)
        );
    }

    async loadConversations(silent=false) {
        try {
            const rows = await this.orm.searchRead(
                "rubika.conversation",
                [["state", "=", "open"]],
                ["name","partner_id","chat_id","last_message","last_message_at","unread_count","message_count","account_id"],
                {order: "last_message_at desc, id desc", limit: 200}
            );
            this.state.conversations = rows.map(r => ({
                ...r,
                partner_name: r.partner_id ? r.partner_id[1] : "",
                account_name: r.account_id ? r.account_id[1] : "",
            }));
            if (this.state.selectedId) {
                const c = this.state.conversations.find(x => x.id === this.state.selectedId);
                if (c) this.state.selected = c;
            } else if (this.state.conversations.length) {
                await this.selectConversation(this.state.conversations[0]);
            }
        } catch (e) {
            if (!silent) this.notify("خطا در دریافت گفتگوها", "danger");
        } finally {
            this.state.loading = false;
        }
    }

    toggleInfo() {
        this.state.showInfo = !this.state.showInfo;
    }

    onConversationClick(c) {
        return this.selectConversation(c);
    }

    async selectConversation(c) {
        this.state.selectedId = c.id;
        this.state.selected = c;
        this.state.showInfo = false;
        try {
            this.state.messages = await this.orm.searchRead(
                "rubika.message",
                [["conversation_id", "=", c.id]],
                ["id","direction","message_type","body","sent_at","status","attachment_ids","create_date","error_message"],
                {order: "create_date asc", limit: 500}
            );
            await this.orm.call("rubika.conversation", "action_mark_read", [[c.id]]);
            c.unread_count = 0;
            setTimeout(() => this.scrollToBottom(), 50);
        } catch (e) {
            this.notify("خطا در دریافت پیام‌ها", "danger");
        }
    }

    scrollToBottom() {
        const el = document.querySelector(".o_rubika_messages");
        if (el) el.scrollTop = el.scrollHeight;
    }

    async sendText() {
        const text = (this.state.draft || "").trim();
        const c = this.state.selected;
        if (!text || !c) return;
        this.state.sending = true;
        try {
            const id = await this.orm.create("rubika.message", [{
                conversation_id: c.id,
                account_id: c.account_id[0],
                partner_id: c.partner_id ? c.partner_id[0] : false,
                direction: "out",
                message_type: "text",
                chat_id: c.chat_id,
                body: text,
                status: "received",
            }]);
            // create() intentionally auto-sends outgoing text in the Python model.
            this.state.draft = "";
            await this.selectConversation(c);
            await this.loadConversations(true);
        } catch (e) {
            this.notify(this.errorText(e), "danger");
        } finally {
            this.state.sending = false;
        }
    }

    onKeydown(ev) {
        if (ev.key === "Enter" && !ev.shiftKey) {
            ev.preventDefault();
            this.sendText();
        }
    }

    openFilePicker() {
        this.state.showAttachmentMenu = false;
        this.fileInput.el.click();
    }

    async onFilesSelected(ev) {
        const files = [...(ev.target.files || [])];
        ev.target.value = "";
        if (!files.length || !this.state.selected) return;
        for (const file of files) {
            await this.sendFile(file);
        }
    }

    async sendFile(file) {
        const c = this.state.selected;
        this.state.sending = true;
        try {
            const data = await this.readFile(file);
            const attachmentId = await this.orm.create("ir.attachment", [{
                name: file.name,
                type: "binary",
                datas: data.split(",")[1],
                mimetype: file.type || "application/octet-stream",
                res_model: "rubika.conversation",
                res_id: c.id,
            }]);
            const wiz = await this.orm.create("rubika.send.wizard", [{
                account_id: c.account_id[0],
                partner_id: c.partner_id ? c.partner_id[0] : false,
                caption: "",
                attachment_ids: [[6, 0, [attachmentId]]],
            }]);
            await this.orm.call("rubika.send.wizard", "action_send", [[wiz]]);
            this.notify(`${file.name} ارسال شد`, "success");
            await this.selectConversation(c);
            await this.loadConversations(true);
        } catch (e) {
            this.notify(this.errorText(e), "danger");
        } finally {
            this.state.sending = false;
        }
    }

    readFile(file) {
        return new Promise((resolve, reject) => {
            const r = new FileReader();
            r.onload = () => resolve(r.result);
            r.onerror = reject;
            r.readAsDataURL(file);
        });
    }

    async pollNow() {
        try {
            const accounts = await this.orm.searchRead("rubika.account", [["active","=",true]], ["id"]);
            for (const a of accounts) await this.orm.call("rubika.account", "action_poll_now", [[a.id]]);
            await this.loadConversations();
            if (this.state.selected) await this.selectConversation(this.state.selected);
            this.notify("پیام‌ها به‌روزرسانی شدند", "success");
        } catch (e) {
            this.notify(this.errorText(e), "danger");
        }
    }

    async openPartner() {
        const c = this.state.selected;
        if (!c?.partner_id) {
            this.notify("این گفتگو هنوز به مخاطب Odoo متصل نیست.", "warning");
            return;
        }
        const action = await this.orm.call("rubika.conversation", "action_open_partner", [[c.id]]);
        if (action) await this.action.doAction(action);
    }

    notify(message, type="info") {
        this.notification.add(message, {type});
    }

    errorText(e) {
        return e?.data?.message || e?.message || "خطای نامشخص";
    }

    formatTime(value) {
        if (!value) return "";
        const d = new Date(value.replace(" ", "T") + "Z");
        if (Number.isNaN(d.getTime())) return value;
        return d.toLocaleTimeString("fa-IR", {hour: "2-digit", minute: "2-digit"});
    }

    avatar(c) {
        return c?.partner_id ? `/web/image/res.partner/${c.partner_id[0]}/avatar_128` : "/web/static/img/user_menu_avatar.png";
    }

    messageAttachmentUrl(id) {
        return `/web/content/${id}?download=true`;
    }
}
RubikaMessenger.template = "rubika_connector.RubikaMessenger";
registry.category("actions").add("rubika_messenger", RubikaMessenger);
