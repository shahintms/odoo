import uuid

from odoo import _, fields, models
from odoo.exceptions import UserError


class ResPartner(models.Model):
    _inherit = "res.partner"

    rubika_chat_id = fields.Char(string="Rubika Chat ID", index=True, copy=False)
    rubika_user_id = fields.Char(string="Rubika User ID", index=True, copy=False)
    rubika_account_id = fields.Many2one("rubika.account", string="Rubika Bot", copy=False)
    rubika_link_token = fields.Char(
        string="توکن لینک روبیکا",
        index=True,
        copy=False,
        readonly=True,
        help="توکنی که در لینک اختصاصی روبیکای این مخاطب استفاده می‌شود. "
             "پس از اولین استفاده موفق، برای جلوگیری از سوءاستفاده پاک می‌شود.",
    )
    rubika_deep_link = fields.Char(string="لینک اتصال روبیکا", compute="_compute_rubika_deep_link")

    def _compute_rubika_deep_link(self):
        for partner in self:
            partner.rubika_deep_link = partner._get_rubika_deep_link() or False

    def _get_rubika_deep_link(self):
        self.ensure_one()
        if not self.rubika_link_token:
            return False
        account = self.rubika_account_id or self.env["rubika.account"].search([("active", "=", True)], limit=1)
        if not account or not account.bot_username:
            return False
        return account._build_deep_link(self.rubika_link_token)

    def action_generate_rubika_link(self):
        """Create (or reuse) a one-time linking token and show the deep link
        that, once opened by the customer in Rubika, automatically connects
        this contact's chat to this Odoo partner."""
        self.ensure_one()
        account = self.env["rubika.account"].search([("active", "=", True)], limit=1)
        if not account:
            raise UserError(_("ابتدا یک حساب روبیکا فعال تعریف کنید."))
        if not account.bot_username:
            raise UserError(_("نام کاربری بات مشخص نیست. ابتدا از فرم حساب روبیکا «تست اتصال» را بزنید."))
        if not self.rubika_link_token:
            self.rubika_link_token = uuid.uuid4().hex[:16]
        link = account._build_deep_link(self.rubika_link_token)
        self.message_post(
            body=_(
                "لینک اتصال اختصاصی روبیکا برای این مخاطب ساخته شد. "
                "این لینک را یک‌بار برای مشتری ارسال کنید (پیامک/ایمیل/چاپ روی فاکتور). "
                "با اولین بازکردن آن توسط مشتری، مکالمه روبیکا خودکار به همین مخاطب متصل می‌شود:<br/>%s"
            ) % link
        )
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("لینک روبیکا ساخته شد"),
                "message": link,
                "type": "success",
                "sticky": True,
            },
        }

    def action_send_to_rubika(self):
        self.ensure_one()
        if not self.rubika_chat_id:
            raise UserError(_("این مخاطب شناسه چت روبیکا ندارد."))
        return self.env["rubika.send.wizard"].with_context(
            active_model=self._name, active_ids=self.ids, active_id=self.id
        ).action_from_context()
