from . import rubika_account
from . import rubika_conversation
from . import rubika_message
from . import rubika_link_wizard
from . import res_partner

from . import rubika_send_wizard

from . import document_actions
