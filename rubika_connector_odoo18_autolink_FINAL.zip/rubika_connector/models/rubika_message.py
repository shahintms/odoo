import json
from odoo import api, fields, models, _
from odoo.exceptions import UserError


class RubikaMessage(models.Model):
    _name = "rubika.message"
    _description = "Rubika Message"
    _order = "create_date desc"

    conversation_id = fields.Many2one("rubika.conversation", required=True, ondelete="cascade")
    account_id = fields.Many2one("rubika.account", required=True, ondelete="cascade")
    partner_id = fields.Many2one("res.partner", string="Customer", ondelete="set null")
    direction = fields.Selection([("in", "Incoming"), ("out", "Outgoing")], required=True, default="in")
    message_type = fields.Selection(
        [("text", "Text"), ("file", "File"), ("event", "Event")],
        required=True, default="text"
    )
    attachment_ids = fields.Many2many(
        "ir.attachment",
        "rubika_message_attachment_rel",
        "message_id",
        "attachment_id",
        string="Attachments",
    )
    external_message_id = fields.Char(index=True, copy=False)
    sender_id = fields.Char(index=True)
    chat_id = fields.Char(required=True, index=True)
    body = fields.Text()
    raw_payload = fields.Text(readonly=True)
    sent_at = fields.Datetime(default=fields.Datetime.now, readonly=True)
    status = fields.Selection([("received", "Received"), ("sent", "Sent"), ("error", "Error")], default="received")
    error_message = fields.Text(readonly=True)

    @api.model
    def create(self, vals):
        rec = super().create(vals)
        if rec.direction == "out" and rec.status != "sent" and rec.body and rec.message_type == "text":
            rec.send_to_rubika()
        return rec

    def send_to_rubika(self):
        self.ensure_one()
        if not self.account_id.active:
            raise UserError(_("The Rubika account is inactive."))
        if not self.chat_id or not self.body:
            raise UserError(_("Chat ID and message text are required."))
        result = self.account_id._api_call("sendMessage", {
            "chat_id": self.chat_id,
            "text": self.body,
        })
        self.status = "sent"
        self.raw_payload = json.dumps(result, ensure_ascii=False)
        self.sent_at = fields.Datetime.now()
        self.error_message = False
        self.conversation_id.sudo().write({
            "last_message": self.body,
            "last_message_at": fields.Datetime.now(),
            "unread_count": 0,
        })
        return True
