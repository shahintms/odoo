import json
import logging
from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)


class RubikaWebhookController(http.Controller):

    @http.route("/rubika/webhook/<int:account_id>", type="http", auth="public", methods=["POST"], csrf=False)
    def rubika_webhook(self, account_id, **kwargs):
        account = request.env["rubika.account"].sudo().browse(account_id)
        if not account.exists() or not account.active:
            return request.make_json_response({"ok": False, "error": "account_not_found"}, status=404)
        try:
            payload = json.loads(request.httprequest.get_data(as_text=True) or "{}")
            account._process_update(payload)
            return request.make_json_response({"ok": True})
        except Exception as exc:
            _logger.exception("Rubika webhook error")
            return request.make_json_response({"ok": False, "error": str(exc)}, status=400)
