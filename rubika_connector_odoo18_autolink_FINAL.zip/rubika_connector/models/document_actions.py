from odoo import models


class SaleOrder(models.Model):
    _inherit = "sale.order"

    def action_send_to_rubika(self):
        self.ensure_one()
        return self.env["rubika.send.wizard"].with_context(
            active_model=self._name,
            active_ids=self.ids,
            active_id=self.id,
            default_generate_document=True,
        ).action_from_context()


class AccountMove(models.Model):
    _inherit = "account.move"

    def action_send_to_rubika(self):
        self.ensure_one()
        return self.env["rubika.send.wizard"].with_context(
            active_model=self._name,
            active_ids=self.ids,
            active_id=self.id,
            default_generate_document=True,
        ).action_from_context()


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    def action_send_to_rubika(self):
        self.ensure_one()
        return self.env["rubika.send.wizard"].with_context(
            active_model=self._name,
            active_ids=self.ids,
            active_id=self.id,
            default_generate_document=True,
        ).action_from_context()
