from odoo import fields, models, _
from odoo.exceptions import UserError


class RubikaConversation(models.Model):
    _name = "rubika.conversation"
    _description = "Rubika Conversation"
    _order = "last_message_at desc, id desc"

    name = fields.Char(required=True)
    account_id = fields.Many2one("rubika.account", required=True, ondelete="cascade")
    partner_id = fields.Many2one("res.partner", string="Customer", ondelete="set null")
    chat_id = fields.Char(required=True, index=True)
    state = fields.Selection([("open", "Open"), ("closed", "Closed")], default="open", required=True)
    user_id = fields.Many2one("res.users", string="Assigned Salesperson", default=lambda self: self.env.user)
    last_message = fields.Text(readonly=True)
    last_message_at = fields.Datetime(readonly=True)
    unread_count = fields.Integer(default=0)
    message_ids = fields.One2many("rubika.message", "conversation_id")
    message_count = fields.Integer(compute="_compute_message_count")
    is_linked = fields.Boolean(string="Linked to Customer", compute="_compute_is_linked", store=True)

    _sql_constraints = [
        ("account_chat_unique", "unique(account_id, chat_id)", "Each Rubika chat must be unique per bot.")
    ]

    def _compute_message_count(self):
        for rec in self:
            rec.message_count = len(rec.message_ids)

    def _compute_is_linked(self):
        for rec in self:
            rec.is_linked = bool(rec.partner_id)

    def action_mark_read(self):
        self.write({"unread_count": 0})
        return True

    def action_open_partner(self):
        self.ensure_one()
        if not self.partner_id:
            raise UserError(_("This conversation has no customer."))
        return {
            "type": "ir.actions.act_window",
            "res_model": "res.partner",
            "view_mode": "form",
            "res_id": self.partner_id.id,
        }

    def action_link_customer(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "res_model": "rubika.link.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_conversation_id": self.id,
                "default_partner_id": self.partner_id.id if self.partner_id else False,
            },
        }

    def action_unlink_customer(self):
        self.write({"partner_id": False})
        self.message_ids.write({"partner_id": False})
        return True

    def action_send_message(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "res_model": "rubika.message",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_conversation_id": self.id,
                "default_account_id": self.account_id.id,
                "default_partner_id": self.partner_id.id if self.partner_id else False,
                "default_chat_id": self.chat_id,
                "default_direction": "out",
                "default_message_type": "text",
            },
        }
