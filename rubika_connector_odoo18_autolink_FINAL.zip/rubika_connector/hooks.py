from odoo import SUPERUSER_ID


# Models on which the global "Send with Rubika" action is exposed.
ACTION_XML_PREFIX = "rubika_action_send_"


def _column_exists(cr, table, column):
    cr.execute(
        """
        SELECT 1
          FROM information_schema.columns
         WHERE table_schema = current_schema()
           AND table_name = %s
           AND column_name = %s
        """,
        (table, column),
    )
    return bool(cr.fetchone())


def _ensure_column(cr, table, column, sql_type):
    if not _column_exists(cr, table, column):
        # Names are constants from this module, not user input.
        cr.execute('ALTER TABLE "%s" ADD COLUMN "%s" %s' % (table, column, sql_type))


def pre_init_hook(env):
    """Repair columns introduced by the Auto-Link version before registry use.

    This is intentionally defensive: the module may have been copied over an
    already-installed version without an Odoo upgrade. In that situation the
    Python model knows about the field while PostgreSQL does not yet have the
    column, which makes even the Apps page fail with UndefinedColumn.
    """
    cr = env.cr
    # res.partner fields introduced/used by this connector.
    _ensure_column(cr, "res_partner", "rubika_chat_id", "varchar")
    _ensure_column(cr, "res_partner", "rubika_user_id", "varchar")
    _ensure_column(cr, "res_partner", "rubika_account_id", "integer")
    _ensure_column(cr, "res_partner", "rubika_link_token", "varchar")

    # Indexes are useful for the lookup fields and are safe to create only once.
    cr.execute(
        'CREATE INDEX IF NOT EXISTS res_partner_rubika_chat_id_idx '
        'ON res_partner (rubika_chat_id)'
    )
    cr.execute(
        'CREATE INDEX IF NOT EXISTS res_partner_rubika_user_id_idx '
        'ON res_partner (rubika_user_id)'
    )
    cr.execute(
        'CREATE INDEX IF NOT EXISTS res_partner_rubika_link_token_idx '
        'ON res_partner (rubika_link_token)'
    )


def post_init_hook(env):
    _sync_server_actions(env)


def _sync_server_actions(env):
    IrModel = env["ir.model"].sudo()
    ServerAction = env["ir.actions.server"].sudo()

    models = IrModel.search([("model", "!=", False)])
    for ir_model in models:
        model_name = ir_model.model
        try:
            model = env[model_name]
        except Exception:
            continue
        if "message_ids" not in model._fields:
            continue

        partner_field = None
        for fname in ("partner_id", "commercial_partner_id", "customer_id", "contact_id", "client_id"):
            f = model._fields.get(fname)
            if f and getattr(f, "comodel_name", None) == "res.partner":
                partner_field = f
                break
        if not partner_field:
            continue

        xmlid = f"rubika_connector.{ACTION_XML_PREFIX}{model_name.replace('.', '_')}"
        existing = env.ref(xmlid, raise_if_not_found=False)
        vals = {
            "name": "ارسال با روبیکا",
            "model_id": ir_model.id,
            "binding_model_id": ir_model.id,
            "binding_type": "action",
            "state": "code",
            "code": (
                "action = env['rubika.send.wizard'].with_context("
                "active_model=model._name, active_ids=records.ids, "
                "active_id=records[:1].id if records else False).action_from_context()"
            ),
        }
        if existing:
            existing.write(vals)
        else:
            action = ServerAction.create(vals)
            env["ir.model.data"].create({
                "module": "rubika_connector",
                "name": f"{ACTION_XML_PREFIX}{model_name.replace('.', '_')}",
                "model": "ir.actions.server",
                "res_id": action.id,
                "noupdate": True,
            })


def uninstall_hook(env):
    actions = env["ir.actions.server"].sudo().search([
        ("name", "=", "ارسال با روبیکا")
    ])
    # Only remove actions owned by this module.
    xmlids = env["ir.model.data"].sudo().search([
        ("module", "=", "rubika_connector"),
        ("model", "=", "ir.actions.server"),
    ])
    owned_ids = set(xmlids.mapped("res_id"))
    actions.filtered(lambda a: a.id in owned_ids).unlink()
