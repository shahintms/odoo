import base64
import mimetypes
import re

from odoo import api, fields, models, _
from odoo.exceptions import UserError


class RubikaSendWizard(models.TransientModel):
    _name = "rubika.send.wizard"
    _description = "Send Odoo Files to Rubika"

    account_id = fields.Many2one("rubika.account", string="Rubika Bot", required=True)
    partner_id = fields.Many2one("res.partner", string="Rubika Contact", required=True)
    chat_id = fields.Char(related="partner_id.rubika_chat_id", readonly=True)
    caption = fields.Text(string="Message")
    attachment_ids = fields.Many2many(
        "ir.attachment",
        "rubika_send_wizard_attachment_rel",
        "wizard_id",
        "attachment_id",
        string="Files",
    )
    active_model = fields.Char(readonly=True)
    active_res_id = fields.Integer(readonly=True)
    record_name = fields.Char(readonly=True)
    generate_document = fields.Boolean(
        string="ارسال PDF سند",
        default=False,
        help="برای فاکتور، سفارش فروش و اسناد پشتیبانی‌شده، PDF گزارش Odoo را تولید و همراه فایل‌ها ارسال می‌کند.",
    )
    generated_attachment_id = fields.Many2one("ir.attachment", readonly=True, copy=False)

    @api.model
    def _get_default_partner(self, model, record):
        if not record:
            return False
        if model == "res.partner":
            return record
        # Standard Odoo business documents normally use partner_id.
        # The fallbacks cover common custom/CRM naming conventions.
        for field_name in (
            "partner_id", "commercial_partner_id", "customer_id",
            "contact_id", "customer_contact_id", "client_id",
        ):
            if field_name in record._fields and record[field_name]:
                partner = record[field_name]
                if partner._name == "res.partner":
                    return partner.commercial_partner_id
        return False

    @api.model
    def _get_attachments(self, model, record):
        if not record:
            return self.env["ir.attachment"]
        Attachment = self.env["ir.attachment"].sudo()
        direct = Attachment.search([
            ("res_model", "=", model),
            ("res_id", "=", record.id),
            ("type", "=", "binary"),
        ])
        # Also include files attached to chatter messages of this record.
        message_ids = self.env["mail.message"].sudo().search([
            ("model", "=", model), ("res_id", "=", record.id)
        ]).ids
        chatter = Attachment.search([
            ("res_model", "=", "mail.message"),
            ("res_id", "in", message_ids),
            ("type", "=", "binary"),
        ]) if message_ids else Attachment.browse()
        return direct | chatter

    @api.model
    def action_from_context(self):
        model = self.env.context.get("active_model")
        ids = self.env.context.get("active_ids") or []
        if not model or not ids:
            raise UserError(_("ابتدا یک رکورد را انتخاب کنید."))
        if len(ids) > 1:
            raise UserError(_("برای ارسال فایل و پیام، لطفاً فقط یک رکورد را انتخاب کنید."))
        record = self.env[model].browse(ids[0]).exists()
        if not record:
            raise UserError(_("رکورد انتخاب‌شده پیدا نشد."))

        partner = self._get_default_partner(model, record)
        account = self.env["rubika.account"].search([
            ("active", "=", True),
            ("polling_enabled", "=", True),
        ], limit=1)
        if not account:
            account = self.env["rubika.account"].search([("active", "=", True)], limit=1)

        attachments = self._get_attachments(model, record)
        action = {
            "type": "ir.actions.act_window",
            "res_model": "rubika.send.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_active_model": model,
                "default_active_res_id": record.id,
                "default_record_name": record.display_name,
                "default_account_id": account.id if account else False,
                "default_partner_id": partner.id if partner and partner.rubika_chat_id else False,
                "default_attachment_ids": [(6, 0, attachments.ids)],
                "default_generate_document": bool(self.env.context.get("default_generate_document")),
            },
        }
        return action

    def _attachment_type(self, attachment):
        mimetype = attachment.mimetype or mimetypes.guess_type(attachment.name or "")[0] or "application/octet-stream"
        if mimetype.startswith("image/"):
            # Rubika supports image/file media types; Image is appropriate for common image attachments.
            return "Image"
        if mimetype.startswith("video/"):
            return "Video"
        if mimetype.startswith("audio/"):
            return "Voice"
        return "File"

    def _report_xmlids(self, model):
        candidates = {
            "sale.order": ["sale.action_report_saleorder"],
            "account.move": ["account.account_invoices", "account.report_invoice_with_payments"],
            "purchase.order": ["purchase.action_report_purchase_order"],
        }.get(model, [])
        for xmlid in candidates:
            report = self.env.ref(xmlid, raise_if_not_found=False)
            if report:
                return xmlid
        return False

    def _generate_document_attachment(self):
        self.ensure_one()
        if not self.generate_document or not self.active_model or not self.active_res_id:
            return False
        xmlid = self._report_xmlids(self.active_model)
        if not xmlid:
            return False
        report = self.env.ref(xmlid, raise_if_not_found=False)
        if not report:
            return False
        try:
            pdf_content, _ = self.env["ir.actions.report"]._render_qweb_pdf(xmlid, [self.active_res_id])
        except TypeError:
            pdf_content, _ = report._render_qweb_pdf([self.active_res_id])
        record = self.env[self.active_model].browse(self.active_res_id).exists()
        if not record:
            return False
        name = (record.display_name or self.record_name or "document").replace("/", "-") + ".pdf"
        attachment = self.env["ir.attachment"].sudo().create({
            "name": name,
            "type": "binary",
            "datas": base64.b64encode(pdf_content),
            "mimetype": "application/pdf",
            "res_model": self.active_model,
            "res_id": self.active_res_id,
        })
        self.generated_attachment_id = attachment.id
        self.attachment_ids = [(4, attachment.id)]
        return attachment

    def action_send(self):
        self.ensure_one()
        if not self.partner_id.rubika_chat_id:
            raise UserError(_("این مخاطب شناسه چت روبیکا ندارد. ابتدا مخاطب را به حساب روبیکا متصل کنید."))
        if not self.account_id.active:
            raise UserError(_("حساب روبیکا غیرفعال است."))

        # Generate the native Odoo PDF before sending, when requested.
        self._generate_document_attachment()

        if not self.attachment_ids and not self.caption:
            raise UserError(_("حداقل یک فایل یا متن برای ارسال انتخاب کنید."))

        # With files, the caption is attached to the single file when possible;
        # for multiple files it is sent once as a text message before the files.
        if self.caption and not self.attachment_ids:
            self.account_id._api_call("sendMessage", {
                "chat_id": self.partner_id.rubika_chat_id,
                "text": self.caption,
            })
        elif self.caption and len(self.attachment_ids) > 1:
            self.account_id._api_call("sendMessage", {
                "chat_id": self.partner_id.rubika_chat_id,
                "text": self.caption,
            })

        for attachment in self.attachment_ids:
            data = attachment.datas
            if not data:
                continue
            file_bytes = base64.b64decode(data)
            result = self.account_id._upload_and_send_file(
                chat_id=self.partner_id.rubika_chat_id,
                filename=attachment.name or "file",
                file_bytes=file_bytes,
                mimetype=attachment.mimetype or "application/octet-stream",
                caption=self.caption if self.caption and len(self.attachment_ids) == 1 else "",
            )
            # Store a local message record for audit/history.
            conversation = self.env["rubika.conversation"].sudo().search([
                ("account_id", "=", self.account_id.id),
                ("chat_id", "=", self.partner_id.rubika_chat_id),
            ], limit=1)
            if not conversation:
                conversation = self.env["rubika.conversation"].sudo().create({
                    "name": self.partner_id.name,
                    "account_id": self.account_id.id,
                    "chat_id": self.partner_id.rubika_chat_id,
                    "partner_id": self.partner_id.id,
                })
            self.env["rubika.message"].sudo().create({
                "conversation_id": conversation.id,
                "account_id": self.account_id.id,
                "partner_id": self.partner_id.id,
                "direction": "out",
                "message_type": "file",
                "chat_id": self.partner_id.rubika_chat_id,
                "body": self.caption or attachment.name,
                "attachment_ids": [(4, attachment.id)],
                "status": "sent",
            })
            conversation.sudo().write({
                "last_message": self.caption or attachment.name,
                "last_message_at": fields.Datetime.now(),
                "unread_count": 0,
            })

        if not self.caption and not self.attachment_ids:
            raise UserError(_("حداقل یک پیام یا فایل انتخاب کنید."))

        return {"type": "ir.actions.act_window_close"}
